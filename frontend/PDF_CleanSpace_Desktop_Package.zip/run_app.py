#!/usr/bin/env python3
"""
One-Click Launcher for PDF CleanSpace Web Application
Installs dependencies, starts backend server, and launches web browser.
"""

import sys
import os
import subprocess
import webbrowser
import time

def check_and_install_deps():
    required_packages = ["fitz", "fastapi", "uvicorn", "PIL"]
    missing = []

    for pkg in required_packages:
        try:
            if pkg == "fitz":
                import fitz
            elif pkg == "fastapi":
                import fastapi
            elif pkg == "uvicorn":
                import uvicorn
            elif pkg == "PIL":
                import PIL
        except ImportError:
            missing.append(pkg)

    if missing:
        print("Installing required Python packages (PyMuPDF, FastAPI, Uvicorn, Pillow)...")
        req_file = os.path.join(os.path.dirname(__file__), "requirements.txt")
        if os.path.exists(req_file):
            subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", req_file])
        else:
            subprocess.check_call([sys.executable, "-m", "pip", "install", "PyMuPDF", "fastapi", "uvicorn", "Pillow", "python-multipart"])
        print("✓ Dependencies successfully installed!\n")

def main():
    print("=" * 60)
    print(" ⚡ PDF CleanSpace - Starting Web Application")
    print("=" * 60)
    
    check_and_install_deps()

    import uvicorn

    host = "127.0.0.1"
    port = 8000
    url = f"http://{host}:{port}/"

    print(f"Starting local server at {url}")
    print("Launching web browser...")

    webbrowser.open(url)

    uvicorn.run("backend.app:app", host=host, port=port, reload=True)

if __name__ == "__main__":
    main()
