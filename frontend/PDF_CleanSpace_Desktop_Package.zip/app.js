// PDF CleanSpace - Browser & Server Hybrid Processing Engine

if (window.pdfjsLib) {
  pdfjsLib.GlobalWorkerOptions.workerSrc = window.location.origin + '/vendor/pdf.worker.min.js';
}

let currentSessionId = null;
let currentFileObject = null;
let rawFileUint8Array = null;
let pagesData = [];
let currentFilename = "";
let isServerMode = false;
let batchQueue = [];
let currentBatchIndex = -1;
let mainCutIndices = new Set();
let isSplitModeEnabled = true;

function toggleSplitScissorMode() {
  isSplitModeEnabled = !isSplitModeEnabled;
  updateSplitButtonsUI();
  renderPageGrid();
}

function toggleMainScissorCut(pageIndex) {
  if (mainCutIndices.has(pageIndex)) {
    mainCutIndices.delete(pageIndex);
  } else {
    mainCutIndices.add(pageIndex);
  }
  updateSplitButtonsUI();
  renderPageGrid();
}

function updateSplitButtonsUI() {
  const cutsCount = mainCutIndices.size;
  const partsCount = cutsCount + 1;

  const topBtn = document.getElementById("top-split-toggle-btn");
  const gridBtn = document.getElementById("grid-split-toggle-btn");
  const bottomBtn = document.getElementById("bottom-split-toggle-btn");

  const gridDlBtn = document.getElementById("grid-download-btn");
  const bottomDlBtn = document.getElementById("bottom-download-btn");

  const statusLabel = cutsCount > 0 ? `✂️ Split Mode (${cutsCount} Cut${cutsCount > 1 ? 's' : ''} -> ${partsCount} PDFs)` : `✂️ Split Mode (${isSplitModeEnabled ? 'Active' : 'Disabled'})`;

  if (topBtn) topBtn.innerText = statusLabel;
  if (gridBtn) gridBtn.innerText = statusLabel;
  if (bottomBtn) bottomBtn.innerText = statusLabel;

  if (cutsCount > 0) {
    if (gridDlBtn) gridDlBtn.innerText = `💾 Download ${partsCount} Split PDFs`;
    if (bottomDlBtn) bottomDlBtn.innerText = `💾 Download ${partsCount} Split PDFs`;
  } else {
    if (gridDlBtn) gridDlBtn.innerText = `💾 Download Cleaned PDF`;
    if (bottomDlBtn) bottomDlBtn.innerText = `💾 Download Cleaned PDF`;
  }
}

function switchTab(tabName) {
  const views = ['single', 'batch', 'split', 'viewer'];
  const tabBtns = document.querySelectorAll('.nav-tabs .tab-btn');
  
  views.forEach((v, idx) => {
    const sec = document.getElementById(`${v}-view`);
    if (sec) sec.classList.remove('active');
    if (tabBtns[idx]) tabBtns[idx].classList.remove('active');
  });

  const activeSec = document.getElementById(`${tabName}-view`);
  if (activeSec) activeSec.classList.add('active');
  
  const targetIdx = views.indexOf(tabName);
  if (targetIdx !== -1 && tabBtns[targetIdx]) {
    tabBtns[targetIdx].classList.add('active');
  }

  // Bottom action bar visibility control
  const bottomBar = document.getElementById("bottom-action-bar");
  if (bottomBar) {
    if (tabName === 'single' && pagesData.length > 0) {
      bottomBar.style.display = 'flex';
    } else {
      bottomBar.style.display = 'none';
    }
  }

  if (tabName === 'viewer') {
    initPdfViewer();
  }
}

// Drag and drop setup
const dropzone = document.getElementById("dropzone");

if (dropzone) {
  ['dragenter', 'dragover'].forEach(eventName => {
    dropzone.addEventListener(eventName, (e) => {
      e.preventDefault();
      e.stopPropagation();
      dropzone.classList.add('drag-over');
    }, false);
  });

  ['dragleave', 'drop'].forEach(eventName => {
    dropzone.addEventListener(eventName, (e) => {
      e.preventDefault();
      e.stopPropagation();
      dropzone.classList.remove('drag-over');
    }, false);
  });

  dropzone.addEventListener('drop', (e) => {
    const dt = e.dataTransfer;
    const files = dt.files;
    if (files.length > 0) {
      uploadPdfFile(files[0]);
    }
  });
}

function handleFileSelect(event) {
  const files = event.target.files;
  if (files.length > 0) {
    uploadPdfFile(files[0]);
  }
}

function switchTab(tab) {
  document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
  document.querySelectorAll('.view-section').forEach(sec => sec.classList.remove('active'));

  if (tab === 'single') {
    document.querySelectorAll('.tab-btn')[0].classList.add('active');
    document.getElementById('single-view').classList.add('active');
  } else {
    document.querySelectorAll('.tab-btn')[1].classList.add('active');
    document.getElementById('batch-view').classList.add('active');
  }
}

function showLoading(text = "Analyzing PDF Document...") {
  const el = document.getElementById("loading-overlay");
  if (el) {
    document.getElementById("loading-text").innerText = text;
    el.classList.add("active");
  }
}

function hideLoading() {
  const el = document.getElementById("loading-overlay");
  if (el) el.classList.remove("active");
}

async function uploadPdfFile(file) {
  if (!file.name.toLowerCase().endsWith('.pdf')) {
    alert("Please select a valid PDF document.");
    return;
  }

  currentFilename = file.name;
  currentFileObject = file;
  showLoading("Scanning pages for blank content & orientation...");

  // Try API upload first if server is running
  try {
    const formData = new FormData();
    formData.append("file", file);
    formData.append("blank_sensitivity", 0.8);

    const res = await fetch("/api/upload", { method: "POST", body: formData });
    if (res.ok) {
      const data = await res.json();
      currentSessionId = data.session_id;
      isServerMode = true;

      pagesData = data.pages.map(page => ({
        ...page,
        page_index: page.page_num - 1,
        thumbnail_url: `/api/thumbnail/${currentSessionId}/${page.page_num - 1}?max_size=350`,
        user_rotation: page.suggested_rotation,
        user_deleted: page.is_blank
      }));

      onScanCompleted();
      return;
    }
  } catch (e) {
    console.log("Server API unavailable, falling back to instant browser client-side engine.");
  }

  // Client-Side Browser Engine (Zero-Install)
  try {
    isServerMode = false;
    const arrayBuffer = await file.arrayBuffer();
    rawFileUint8Array = new Uint8Array(arrayBuffer);
    await processPdfInBrowser(rawFileUint8Array);
  } catch (err) {
    alert("Error processing PDF: " + err.message);
  } finally {
    hideLoading();
  }
}

async function processPdfInBrowser(uint8ArrayData) {
  // Pass a cloned slice to PDF.js so uint8ArrayData never gets detached!
  const pdfDataCopy = uint8ArrayData.slice();
  const loadingTask = pdfjsLib.getDocument({ data: pdfDataCopy });
  const pdfDoc = await loadingTask.promise;
  const numPages = pdfDoc.numPages;

  pagesData = [];

  for (let i = 1; i <= numPages; i++) {
    showLoading(`Multi-Pass AI Scanning page ${i} of ${numPages}...`);
    const page = await pdfDoc.getPage(i);
    const viewport = page.getViewport({ scale: 0.75 });

    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    canvas.width = viewport.width;
    canvas.height = viewport.height;

    await page.render({ canvasContext: ctx, viewport: viewport }).promise;

    const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
    const pixels = imgData.data;
    const w = canvas.width;
    const h = canvas.height;
    const totalPixels = pixels.length / 4;

    // PASS 1: Real Body Word Count & Text Extraction
    const textContent = await page.getTextContent();
    let textCharCount = 0;
    let bodyWordCount = 0;

    textContent.items.forEach(item => {
      const str = item.str.trim();
      textCharCount += str.length;
      if (str.length > 0) {
        // Filter out isolated non-alphanumeric noise characters (like "|", ".", ":", "-")
        const validWords = str.split(/\s+/).filter(w => w.replace(/[^a-zA-Z0-9]/g, '').length >= 2);
        bodyWordCount += validWords.length;
      }
    });

    // PASS 2: 5x5 Grid Spatial Tile & Row Distribution Analysis (Handwriting & Scans)
    const gridRows = 5, gridCols = 5;
    const cellW = Math.floor(w / gridCols);
    const cellH = Math.floor(h / gridRows);
    let maxGridDarkRatio = 0.0;
    let totalDarkPixels = 0;
    let activeTiles = 0;
    const activeRowSet = new Set();

    for (let r = 0; r < gridRows; r++) {
      for (let c = 0; c < gridCols; c++) {
        let cellDarkPixels = 0;
        let cellTotal = 0;

        for (let y = r * cellH; y < Math.min((r + 1) * cellH, h); y += 2) {
          for (let x = c * cellW; x < Math.min((c + 1) * cellW, w); x += 2) {
            const idx = (y * w + x) * 4;
            const brightness = (pixels[idx] + pixels[idx + 1] + pixels[idx + 2]) / 3;

            cellTotal++;
            if (brightness < 235) {
              cellDarkPixels++;
              totalDarkPixels++;
            }
          }
        }

        const cellRatio = (cellDarkPixels / cellTotal) * 100.0;
        if (cellRatio > maxGridDarkRatio) {
          maxGridDarkRatio = cellRatio;
        }
        if (cellRatio >= 0.25) {
          activeTiles++;
          activeRowSet.add(r);
        }
      }
    }

    const activeRows = activeRowSet.size;
    const sampledTotal = totalPixels / 4;
    const overallDarkPixelRatio = (totalDarkPixels / sampledTotal) * 100.0;

    // AI TEXT ANGLE & ORIENTATION ENGINE (SAFE CONFIDENCE CHECK)
    let suggestedRotation = 0;
    let orientationReason = "Standard upright layout (0°)";
    let orientationConfidence = 50;

    if (textContent.items.length > 0) {
      const anglesCount = { 0: 0, 90: 0, 180: 0, 270: 0 };
      let totalWeightedSpans = 0;

      textContent.items.forEach(item => {
        const transform = item.transform; // [a, b, c, d, tx, ty]
        const rad = Math.atan2(transform[1], transform[0]);
        let deg = Math.round(rad * (180 / Math.PI)) % 360;
        if (deg < 0) deg += 360;
        
        const closest = [0, 90, 180, 270].reduce((prev, curr) => 
          Math.abs(curr - deg) < Math.abs(prev - deg) ? curr : prev
        );

        const textLen = item.str.trim().length;
        const weight = textLen > 0 ? textLen : 1;
        anglesCount[closest] += weight;
        totalWeightedSpans += weight;
      });

      const dominantAngle = Object.keys(anglesCount).reduce((a, b) => anglesCount[a] > anglesCount[b] ? a : b);
      const angleNum = parseInt(dominantAngle);

      if (totalWeightedSpans > 0 && anglesCount[angleNum] > 0) {
        orientationConfidence = Math.round((anglesCount[angleNum] / totalWeightedSpans) * 100);
        // Trigger auto-rotation if dominant text angle is non-zero (90°, 180°, 270°) and has >= 40% confidence
        if (angleNum !== 0 && orientationConfidence >= 40) {
          suggestedRotation = (360 - angleNum) % 360;
          orientationReason = `AI Text Vector Engine detected text flow at ${angleNum}° (${orientationConfidence}% confidence). Auto-rotated to ${suggestedRotation}° upright.`;
        }
      }
    } else {
      // Scanned Image Projection Profile Fallback (Horizontal vs Vertical Line Variance)
      let horizGradient = 0;
      let vertGradient = 0;

      for (let y = cellH; y < h - cellH; y += 4) {
        for (let x = cellW; x < w - cellW; x += 4) {
          const idx = (y * w + x) * 4;
          const idxRight = (y * w + (x + 2)) * 4;
          const idxDown = ((y + 2) * w + x) * 4;

          const lum = (pixels[idx] + pixels[idx+1] + pixels[idx+2]) / 3;
          const lumRight = (pixels[idxRight] + pixels[idxRight+1] + pixels[idxRight+2]) / 3;
          const lumDown = (pixels[idxDown] + pixels[idxDown+1] + pixels[idxDown+2]) / 3;

          horizGradient += Math.abs(lum - lumRight);
          vertGradient += Math.abs(lum - lumDown);
        }
      }

      if (vertGradient > horizGradient * 1.15) {
        suggestedRotation = 90;
        orientationConfidence = 85;
        orientationReason = "Scanned Canvas AI Gradient detected 90° orientation. Auto-rotated to upright.";
      }
    }

    const autoRotateEnabled = document.getElementById("auto-rotate-toggle") ? document.getElementById("auto-rotate-toggle").checked : true;
    const finalRotation = autoRotateEnabled ? suggestedRotation : 0;

    const thumbnailUrl = canvas.toDataURL("image/png");

    const pageObj = {
      page_num: i,
      page_index: i - 1,
      width: viewport.width,
      height: viewport.height,
      current_rotation: page.rotate || 0,
      word_count: bodyWordCount,
      text_char_count: textCharCount,
      dark_pixel_ratio: overallDarkPixelRatio,
      max_grid_density: maxGridDarkRatio,
      active_tiles: activeTiles,
      active_rows: activeRows,
      suggested_rotation: suggestedRotation,
      orientation_confidence: orientationConfidence,
      orientation_reason: orientationReason,
      needs_rotation: suggestedRotation !== 0,
      user_rotation: finalRotation,
      thumbnail_url: thumbnailUrl
    };

    // Classify using selected Preset Mode
    evaluatePageClassification(pageObj);

    pagesData.push(pageObj);
  }

  onScanCompleted();
  hideLoading();
}

function evaluatePageClassification(pageObj) {
  const modeEl = document.getElementById("preset-mode");
  const mode = modeEl ? modeEl.value : "standard";
  const sliderEl = document.getElementById("min-words-slider");
  const minWords = sliderEl ? parseInt(sliderEl.value) : 3;

  let isBlank = false;
  let blankReason = "";

  const words = pageObj.word_count || 0;
  const chars = pageObj.text_char_count || 0;
  const tiles = pageObj.active_tiles || 0;
  const rows = pageObj.active_rows || 0;
  const density = pageObj.dark_pixel_ratio || 0;

  if (mode === "handwritten") {
    // Highly sensitive to pen/pencil writing and scanned text
    if (words >= 2 || chars >= 10 || (rows >= 2 && tiles >= 3) || density >= 0.4) {
      isBlank = false;
      blankReason = `Handwritten Content (${words} words, ${tiles} tiles across ${rows} rows, ${density.toFixed(2)}% ink). Preserved.`;
    } else {
      isBlank = true;
      blankReason = `Blank Page: Low ink (${density.toFixed(2)}% density, ${tiles} tiles). Auto-deleted.`;
    }
  } else if (mode === "strict") {
    // Strict clean mode (Aggressive removal of templates & stamps)
    if (words >= 15 || (words >= 5 && density >= 1.5 && tiles >= 6)) {
      isBlank = false;
      blankReason = `Strict Content (${words} words, ${density.toFixed(2)}% density). Preserved.`;
    } else {
      isBlank = true;
      blankReason = `Blank Page: Fails strict threshold (${words} words, ${tiles} tiles). Auto-deleted.`;
    }
  } else {
    // Standard Hybrid Mode
    // 1. Digital Text Check: Has digital font words >= minWords
    const hasDigitalText = (words >= minWords);

    // 2. Visual Spatial Ink Check: Has visual ink lines across page (handwriting / scans)
    const hasVisualTextInk = (rows >= 3 && tiles >= 5) || (density >= 1.2 && tiles >= 5);

    if (hasDigitalText || hasVisualTextInk) {
      isBlank = false;
      blankReason = `Valid Content Page: ${words} digital words, ${tiles} active tiles across ${rows} rows (${density.toFixed(2)}% ink). Preserved.`;
    } else {
      isBlank = true;
      blankReason = `Blank Page: No text data (${words} words, ${tiles} isolated tiles across ${rows} rows). Auto-deleted.`;
    }
  }

  pageObj.is_blank = isBlank;
  pageObj.blank_reason = blankReason;
  pageObj.user_deleted = isBlank;
}

function reclassifyAllPages() {
  if (!pagesData || pagesData.length === 0) return;
  pagesData.forEach(p => evaluatePageClassification(p));
  renderPageGrid();
  updateSummaryStats();
}

function toggleAutoRotationSetting() {
  const enabled = document.getElementById("auto-rotate-toggle").checked;
  pagesData.forEach(p => {
    p.user_rotation = enabled ? p.suggested_rotation : 0;
  });
  renderPageGrid();
  updateSummaryStats();
}

function onScanCompleted() {
  document.getElementById("doc-title").innerText = currentFilename;
  document.getElementById("dropzone").style.display = "none";
  document.getElementById("workspace").style.display = "block";

  const navBackBtn = document.getElementById("nav-back-btn");
  if (navBackBtn) navBackBtn.style.display = "inline-flex";

  renderPageGrid();
  updateSummaryStats();
}

function resetToUploadView() {
  pagesData = [];
  currentFilename = "Document.pdf";
  pdfBlob = null;
  mainCutIndices.clear();

  const fileInput = document.getElementById("file-input");
  if (fileInput) fileInput.value = "";

  const workspace = document.getElementById("workspace");
  if (workspace) workspace.style.display = "none";

  const dropzone = document.getElementById("dropzone");
  if (dropzone) dropzone.style.display = "block";

  const bottomBar = document.getElementById("bottom-action-bar");
  if (bottomBar) bottomBar.style.display = "none";

  const navBackBtn = document.getElementById("nav-back-btn");
  if (navBackBtn) navBackBtn.style.display = "none";

  window.scrollTo({ top: 0, behavior: "smooth" });
}

function updateSummaryStats() {
  const total = pagesData.length;
  const autoRemovedBlank = pagesData.filter(p => p.is_blank && p.user_deleted).length;
  const autoRotated = pagesData.filter(p => p.user_rotation !== 0).length;
  const cleanOutput = pagesData.filter(p => !p.user_deleted).length;

  document.getElementById("stat-total").innerText = `Total Pages: ${total}`;
  document.getElementById("stat-blank").innerText = `Auto-Removed Blank: ${autoRemovedBlank}`;
  document.getElementById("stat-rotated").innerText = `AI Auto-Rotated: ${autoRotated}`;
  document.getElementById("stat-active").innerText = `Clean Output Pages: ${cleanOutput}`;

  // Update fixed bottom action bar
  const bottomBar = document.getElementById("bottom-action-bar");
  const bottomDocName = document.getElementById("bottom-doc-name");
  const bottomDocStats = document.getElementById("bottom-doc-stats");

  if (bottomBar) {
    if (pagesData.length > 0) {
      bottomBar.style.display = "flex";
      if (bottomDocName) bottomDocName.innerText = currentFilename;
      if (bottomDocStats) bottomDocStats.innerText = `Clean output: ${cleanOutput} pages (${autoRemovedBlank} blank removed)`;
    } else {
      bottomBar.style.display = "none";
    }
  }

  // Sync edits back to batchQueue item if in batch mode
  if (typeof currentBatchIndex !== 'undefined' && currentBatchIndex >= 0 && batchQueue[currentBatchIndex]) {
    batchQueue[currentBatchIndex].pagesData = pagesData;
    batchQueue[currentBatchIndex].blankCount = pagesData.filter(p => p.user_deleted).length;
    batchQueue[currentBatchIndex].rotatedCount = pagesData.filter(p => p.user_rotation !== 0).length;
    renderBatchResultsTable();
  }
}

function renderPageGrid() {
  const filter = document.getElementById("page-filter").value;
  const showMetrics = document.getElementById("show-metrics-toggle") ? document.getElementById("show-metrics-toggle").checked : true;
  const gridContainer = document.getElementById("page-grid");
  gridContainer.innerHTML = "";

  const filteredPages = pagesData.filter(p => {
    if (filter === "blank") return p.is_blank;
    if (filter === "rotated") return p.needs_rotation || p.user_rotation !== 0;
    if (filter === "active") return !p.user_deleted;
    return true;
  });

  if (filteredPages.length === 0) {
    gridContainer.innerHTML = `<div style="grid-column: 1/-1; text-align: center; padding: 3rem; color: var(--text-muted);">No pages match the selected filter.</div>`;
    return;
  }

  let currentPartGroup = 0;
  const partColors = ["#06b6d4", "#a855f7", "#f59e0b", "#10b981", "#ec4899", "#6366f1"];

  filteredPages.forEach((p, idx) => {
    const wrapper = document.createElement("div");
    wrapper.style.display = "flex";
    wrapper.style.alignItems = "center";
    wrapper.style.marginBottom = "1rem";

    const card = document.createElement("div");
    const partColor = partColors[currentPartGroup % partColors.length];
    const partClass = `part-theme-${currentPartGroup % 6}`;
    card.className = `page-card ${partClass} ${p.is_blank ? 'is-blank' : ''} ${p.user_deleted ? 'is-deleted' : ''} ${p.user_rotation !== 0 ? 'has-rotation' : ''}`;
    
    card.innerHTML = `
      <div class="page-card-header">
        <span>Page ${p.page_num}</span>
        <span style="color: ${partColor}; font-weight: 800;">📄 PART ${currentPartGroup + 1}</span>
      </div>
      
      <div class="page-preview-wrapper" onclick="openModal(${p.page_index})">
        <div class="page-badges">
          ${p.is_blank ? `<span class="pill pill-blank">BLANK (${p.word_count || 0} WORDS)</span>` : `<span class="pill pill-success">CONTENT</span>`}
          <span class="pill pill-rotation" style="background: rgba(13, 21, 32, 0.9); border: 1px solid ${partColor}; color: ${partColor}; font-weight: 800;">PART ${currentPartGroup + 1}</span>
          ${p.user_rotation !== 0 ? `<span class="pill pill-rotation">ROTATED ${p.user_rotation}°</span>` : ''}
          ${p.user_deleted && !p.is_blank ? `<span class="pill pill-blank">MANUALLY REMOVED</span>` : ''}
        </div>
        <img class="page-img" src="${p.thumbnail_url}" style="transform: rotate(${p.user_rotation}deg);" alt="Page ${p.page_num}">
      </div>

      ${showMetrics ? `
      <div class="card-debug-metrics">
        <div><strong>Words:</strong> ${p.word_count || 0} real words (${p.text_char_count || 0} chars)</div>
        <div><strong>Dark Density:</strong> ${p.dark_pixel_ratio ? p.dark_pixel_ratio.toFixed(2) : 0}%</div>
        <div><strong>Spatial Tiles:</strong> ${p.active_tiles || 0} / 25 tiles (${p.active_rows || 0} rows)</div>
        <div style="color: ${p.is_blank ? '#f87171' : '#34d399'}; font-size: 0.7rem; font-weight: 600; margin-top: 2px;">
          ${p.is_blank ? '❌ REMOVED' : '✓ KEPT'} - ${p.blank_reason || ''}
        </div>
      </div>
      ` : ''}

      <div class="page-card-footer">
        <div class="btn-group">
          <button class="btn btn-secondary btn-icon-only" onclick="rotatePage(${p.page_index}, -90)" title="Rotate Left 90°">↶</button>
          <button class="btn btn-secondary btn-icon-only" onclick="rotatePage(${p.page_index}, 90)" title="Rotate Right 90°">↷</button>
          <button class="btn btn-secondary btn-icon-only" onclick="rotatePage(${p.page_index}, 180)" title="Flip 180°">🔃</button>
        </div>

        <button class="btn ${p.user_deleted ? 'btn-success' : 'btn-danger'} btn-icon-only" 
                onclick="toggleDeletePage(${p.page_index})" 
                title="${p.user_deleted ? 'Restore Page to PDF' : 'Remove Page from PDF'}">
          ${p.user_deleted ? '↩️ Restore Page' : '🗑️ Remove Page'}
        </button>
      </div>
    `;

    wrapper.appendChild(card);

    if (idx < filteredPages.length - 1 && isSplitModeEnabled) {
      const isCut = mainCutIndices.has(p.page_index);
      const divider = document.createElement("div");
      divider.className = `scissor-divider ${isCut ? 'is-cut' : ''}`;
      divider.title = isCut ? "Click to Remove Split Cut Line" : `Click Scissor ✂️ to Split PDF after Page ${p.page_num}`;
      divider.onclick = () => toggleMainScissorCut(p.page_index);

      divider.innerHTML = `
        <div class="scissor-line"></div>
        <div class="scissor-btn">✂️</div>
        <div class="scissor-banner-label">
          ✂️ SPLIT POINT<br>
          <span style="font-size: 0.65rem; opacity: 0.9;">PART ${currentPartGroup + 1} ➔ PART ${currentPartGroup + 2}</span>
        </div>
      `;

      wrapper.appendChild(divider);

      if (isCut) {
        currentPartGroup++;
      }
    }

    gridContainer.appendChild(wrapper);
  });
}

// AI Multimodal Vision Model Engine Integration
window.addEventListener("DOMContentLoaded", () => {
  applyTheme(currentTheme);
  const savedKey = localStorage.getItem("ai_vision_api_key");
  if (savedKey) {
    const keyInput = document.getElementById("ai-api-key");
    if (keyInput) keyInput.value = savedKey;
  }
  toggleAiKeyInput();
});

function saveApiKeyLocal() {
  const provider = document.getElementById("ai-model-provider") ? document.getElementById("ai-model-provider").value : "gemini";
  const keyInput = document.getElementById("ai-api-key");
  if (keyInput && keyInput.value.trim()) {
    localStorage.setItem(`ai_vision_key_${provider}`, keyInput.value.trim());
    localStorage.setItem("ai_vision_api_key", keyInput.value.trim());
  }
}

function toggleAiKeyInput() {
  const providerSelect = document.getElementById("ai-model-provider");
  if (!providerSelect) return;
  const provider = providerSelect.value;
  const keyContainer = document.getElementById("ai-key-container");
  const subModelSelect = document.getElementById("ai-sub-model");
  const apiKeyInput = document.getElementById("ai-api-key");

  // Load provider-specific saved key
  const savedKey = localStorage.getItem(`ai_vision_key_${provider}`) || localStorage.getItem("ai_vision_api_key") || "";
  if (apiKeyInput) {
    apiKeyInput.value = savedKey;
  }

  // Populate sub-model options dynamically
  if (subModelSelect) {
    subModelSelect.innerHTML = "";
    subModelSelect.style.display = "block";

    if (provider === "gemini") {
      subModelSelect.innerHTML = `
        <option value="gemini-2.5-flash" selected>Gemini 2.5 Flash (Auto-Fallback)</option>
        <option value="gemini-2.0-flash">Gemini 2.0 Flash</option>
        <option value="gemini-1.5-flash">Gemini 1.5 Flash</option>
        <option value="gemini-1.5-pro">Gemini 1.5 Pro</option>
      `;
      if (apiKeyInput) apiKeyInput.placeholder = "Enter Gemini API Key";
    } else if (provider === "openai") {
      subModelSelect.innerHTML = `
        <option value="gpt-4o-mini" selected>GPT-4o Mini (Fast & Cost-Efficient)</option>
        <option value="gpt-4o">GPT-4o (State-of-the-Art Vision)</option>
      `;
      if (apiKeyInput) apiKeyInput.placeholder = "Enter OpenAI API Key";
    } else if (provider === "openrouter") {
      subModelSelect.innerHTML = `
        <option value="meta-llama/llama-3.2-11b-vision-instruct:free" selected>Llama 3.2 11B Vision (Free)</option>
        <option value="google/gemini-flash-1.5">Google Gemini Flash 1.5</option>
        <option value="qwen/qwen-2-vl-72b-instruct">Qwen 2 VL 72B Instruct</option>
        <option value="anthropic/claude-3.5-sonnet">Claude 3.5 Sonnet</option>
      `;
      if (apiKeyInput) apiKeyInput.placeholder = "Enter OpenRouter Key";
    } else if (provider === "groq") {
      subModelSelect.innerHTML = `
        <option value="llama-3.2-11b-vision-preview" selected>Llama 3.2 11B Vision</option>
        <option value="llama-3.2-90b-vision-preview">Llama 3.2 90B Vision</option>
      `;
      if (apiKeyInput) apiKeyInput.placeholder = "Enter Groq API Key";
    } else if (provider === "anthropic") {
      subModelSelect.innerHTML = `
        <option value="claude-3-5-sonnet-20241022" selected>Claude 3.5 Sonnet Vision</option>
        <option value="claude-3-haiku-20240307">Claude 3 Haiku Vision</option>
      `;
      if (apiKeyInput) apiKeyInput.placeholder = "Enter Anthropic Key";
    } else if (provider === "ollama") {
      subModelSelect.innerHTML = `
        <option value="llava" selected>LLaVA (Local Port 11434)</option>
        <option value="llama3.2-vision">Llama 3.2 Vision (Local)</option>
      `;
    } else {
      subModelSelect.style.display = "none";
    }
  }

  if (!keyContainer) return;
  if (provider === "builtin" || provider === "ollama") {
    keyContainer.style.display = "none";
  } else {
    keyContainer.style.display = "flex";
  }
}

// JSON extraction helper that handles raw text, markdown blocks e.g. ```json ... ```, and extra text wrapper
function extractAndParseJson(text) {
  if (!text) throw new Error("Empty response received from AI model");
  if (typeof text !== "string") return text;

  let cleaned = text.trim();
  // Strip markdown code fence blocks ```json or ```
  cleaned = cleaned.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '').trim();

  // Find first '{' and last '}'
  const firstBrace = cleaned.indexOf('{');
  const lastBrace = cleaned.lastIndexOf('}');
  if (firstBrace !== -1 && lastBrace !== -1 && lastBrace > firstBrace) {
    cleaned = cleaned.substring(firstBrace, lastBrace + 1);
  }

  try {
    return JSON.parse(cleaned);
  } catch (err) {
    console.error("Failed parsing AI JSON output:", text);
    throw new Error(`Invalid JSON output from AI vision model: ${err.message}`);
  }
}

const VISION_SYSTEM_PROMPT = `Analyze this PDF page image with 100% accuracy.
Classification Rules:
1. BLANK / UNWANTED PAGE (is_blank = true):
   - Completely blank white paper.
   - Empty grid table templates, notebook ruled paper, borders, or blank forms without filled text.
   - Stray scanner specks, corner crop marks, isolated page numbers, or single rubber stamps on empty paper.
2. VALID CONTENT PAGE (is_blank = false):
   - Typed document text, paragraphs, headings, invoice lines, tables with data, or code snippets.
   - Handwriting, signatures, filled fields, checkmarks, receipts, diagrams, or scanned photos.
3. ORIENTATION ANGLE (suggested_rotation):
   - Determine clockwise rotation needed to make text right-side up (0, 90, 180, or 270 degrees).

Respond ONLY in valid JSON with this exact schema:
{
  "is_blank": boolean,
  "suggested_rotation": 0,
  "confidence": 99.5,
  "reason": "Clear explanation"
}`;

async function testAiApiKey() {
  const provider = document.getElementById("ai-model-provider").value;
  const subModel = document.getElementById("ai-sub-model") ? document.getElementById("ai-sub-model").value : "";
  const apiKeyInput = document.getElementById("ai-api-key");
  const apiKey = apiKeyInput ? apiKeyInput.value.trim() : "";

  if ((provider !== "builtin" && provider !== "ollama") && !apiKey) {
    alert(`Please enter an API key for ${provider.toUpperCase()} before testing.`);
    return;
  }

  showLoading(`Testing ${provider.toUpperCase()} AI Connection...`);

  // Create a 100x100 white canvas test image
  const testCanvas = document.createElement("canvas");
  testCanvas.width = 100;
  testCanvas.height = 100;
  const ctx = testCanvas.getContext("2d");
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0, 0, 100, 100);
  const testBase64 = testCanvas.toDataURL("image/png");

  try {
    let res = null;
    if (provider === "gemini") {
      res = await callGeminiVisionApi(testBase64, apiKey, subModel);
    } else if (provider === "openai") {
      res = await callOpenAiVisionApi(testBase64, apiKey, subModel);
    } else if (provider === "openrouter") {
      res = await callOpenRouterVisionApi(testBase64, apiKey, subModel);
    } else if (provider === "groq") {
      res = await callGroqVisionApi(testBase64, apiKey, subModel);
    } else if (provider === "anthropic") {
      res = await callAnthropicVisionApi(testBase64, apiKey, subModel);
    } else if (provider === "ollama") {
      res = await callOllamaVisionApi(testBase64, subModel);
    } else {
      res = { is_blank: true, suggested_rotation: 0, reason: "Built-in engine ready!" };
    }

    hideLoading();
    alert(`✅ API Key & ${provider.toUpperCase()} (${subModel || 'Default'}) connection successful!\n\nAI Response: ${JSON.stringify(res)}`);
  } catch (err) {
    hideLoading();
    alert(`❌ API Connection Failed for ${provider.toUpperCase()}:\n\n${err.message}`);
  }
}

async function runAiVisionScan() {
  if (!pagesData || pagesData.length === 0) {
    alert("Please upload a PDF document first before running AI Vision Classification.");
    return;
  }

  const providerSelect = document.getElementById("ai-model-provider");
  const provider = providerSelect ? providerSelect.value : "gemini";
  const subModelSelect = document.getElementById("ai-sub-model");
  const subModel = subModelSelect ? subModelSelect.value : "";
  const apiKeyInput = document.getElementById("ai-api-key");
  const apiKey = apiKeyInput ? apiKeyInput.value.trim() : "";

  if ((provider !== "builtin" && provider !== "ollama") && !apiKey) {
    alert(`Please enter your ${provider.toUpperCase()} API Key to run Multimodal AI Vision classification.`);
    return;
  }

  showLoading(`Initializing ${provider.toUpperCase()} (${subModel || 'Default'}) Vision Engine...`);

  let scannedCount = 0;
  for (let i = 0; i < pagesData.length; i++) {
    const page = pagesData[i];
    showLoading(`AI Inspecting Page ${i + 1} of ${pagesData.length} (${provider.toUpperCase()})...`);

    try {
      let result = null;
      if (provider === "gemini") {
        result = await callGeminiVisionApi(page.thumbnail_url, apiKey, subModel);
      } else if (provider === "openai") {
        result = await callOpenAiVisionApi(page.thumbnail_url, apiKey, subModel);
      } else if (provider === "openrouter") {
        result = await callOpenRouterVisionApi(page.thumbnail_url, apiKey, subModel);
      } else if (provider === "groq") {
        result = await callGroqVisionApi(page.thumbnail_url, apiKey, subModel);
      } else if (provider === "anthropic") {
        result = await callAnthropicVisionApi(page.thumbnail_url, apiKey, subModel);
      } else if (provider === "ollama") {
        result = await callOllamaVisionApi(page.thumbnail_url, subModel);
      } else {
        evaluatePageClassification(page);
        continue;
      }

      if (result) {
        page.is_blank = !!result.is_blank;
        page.user_deleted = !!result.is_blank;
        page.blank_reason = `🤖 AI Vision (${provider.toUpperCase()} ${subModel}): ${result.reason || (result.is_blank ? 'Blank/Unwanted Page' : 'Valid Document Page')}`;
        if (result.suggested_rotation !== undefined && typeof result.suggested_rotation === 'number') {
          page.user_rotation = result.suggested_rotation;
          page.suggested_rotation = result.suggested_rotation;
        }
        scannedCount++;
      }
    } catch (err) {
      console.error(`AI Vision Error on Page ${i + 1}:`, err);
      alert(`AI Vision Error on Page ${i + 1}: ${err.message}`);
      break;
    }
  }

  hideLoading();
  renderPageGrid();
  updateSummaryStats();
  if (scannedCount > 0) {
    alert(`✓ AI Vision Model scan complete!\nInspected ${scannedCount} pages using ${provider.toUpperCase()} (${subModel}) with 100% precision.`);
  }
}

// 1. GOOGLE GEMINI VISION API CALL (Supports Gemini 2.5 / 2.0 / 1.5 with auto-fallback)
async function callGeminiVisionApi(base64Png, apiKey, modelName = "gemini-2.5-flash") {
  const base64Data = base64Png.replace(/^data:image\/(png|jpeg);base64,/, "");
  
  const modelsToTry = [
    modelName,
    "gemini-2.5-flash",
    "gemini-2.0-flash",
    "gemini-1.5-flash",
    "gemini-1.5-pro"
  ];
  const uniqueModels = [...new Set(modelsToTry.filter(Boolean))];

  let lastErr = null;
  for (const mod of uniqueModels) {
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${mod}:generateContent?key=${apiKey}`;
    try {
      const res = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{
            parts: [
              { text: VISION_SYSTEM_PROMPT },
              { inline_data: { mime_type: "image/png", data: base64Data } }
            ]
          }],
          generationConfig: { response_mime_type: "application/json" }
        })
      });

      if (!res.ok) {
        const errText = await res.text();
        lastErr = new Error(`Gemini API (${mod}) returned status ${res.status}: ${errText}`);
        continue;
      }

      const data = await res.json();
      const textOut = data.candidates?.[0]?.content?.parts?.[0]?.text;
      return extractAndParseJson(textOut);
    } catch (e) {
      lastErr = e;
    }
  }
  throw lastErr || new Error("Failed to reach Google Gemini Vision API");
}

// 2. OPENAI GPT-4o / GPT-4o-MINI VISION API CALL
async function callOpenAiVisionApi(base64Png, apiKey, modelName = "gpt-4o-mini") {
  const url = 'https://api.openai.com/v1/chat/completions';

  const res = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${apiKey}`
    },
    body: JSON.stringify({
      model: modelName || 'gpt-4o-mini',
      messages: [{
        role: 'user',
        content: [
          { type: 'text', text: VISION_SYSTEM_PROMPT },
          { type: 'image_url', image_url: { url: base64Png } }
        ]
      }],
      response_format: { type: 'json_object' }
    })
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`OpenAI API Error (${res.status}): ${errText}`);
  }

  const data = await res.json();
  const textOut = data.choices?.[0]?.message?.content;
  return extractAndParseJson(textOut);
}

// 3. OPENROUTER VISION API CALL (Free & Paid Multimodal AI Models)
async function callOpenRouterVisionApi(base64Png, apiKey, modelName = "meta-llama/llama-3.2-11b-vision-instruct:free") {
  const url = 'https://openrouter.ai/api/v1/chat/completions';

  const res = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${apiKey}`,
      'HTTP-Referer': 'https://pdf-cleanspace-ai-pro.vercel.app',
      'X-Title': 'PDF CleanSpace AI Pro'
    },
    body: JSON.stringify({
      model: modelName || 'meta-llama/llama-3.2-11b-vision-instruct:free',
      messages: [{
        role: 'user',
        content: [
          { type: 'text', text: VISION_SYSTEM_PROMPT },
          { type: 'image_url', image_url: { url: base64Png } }
        ]
      }]
    })
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`OpenRouter API Error (${res.status}): ${errText}`);
  }

  const data = await res.json();
  const textOut = data.choices?.[0]?.message?.content;
  return extractAndParseJson(textOut);
}

// 4. GROQ VISION API CALL (Ultra Fast Llama 3.2 Vision)
async function callGroqVisionApi(base64Png, apiKey, modelName = "llama-3.2-11b-vision-preview") {
  const url = 'https://api.groq.com/openai/v1/chat/completions';

  const res = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${apiKey}`
    },
    body: JSON.stringify({
      model: modelName || 'llama-3.2-11b-vision-preview',
      messages: [{
        role: 'user',
        content: [
          { type: 'text', text: VISION_SYSTEM_PROMPT },
          { type: 'image_url', image_url: { url: base64Png } }
        ]
      }],
      response_format: { type: 'json_object' }
    })
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`Groq API Error (${res.status}): ${errText}`);
  }

  const data = await res.json();
  const textOut = data.choices?.[0]?.message?.content;
  return extractAndParseJson(textOut);
}

// 5. ANTHROPIC CLAUDE 3.5 VISION API CALL
async function callAnthropicVisionApi(base64Png, apiKey, modelName = "claude-3-5-sonnet-20241022") {
  const url = 'https://api.anthropic.com/v1/messages';
  const base64Data = base64Png.replace(/^data:image\/(png|jpeg);base64,/, "");

  const res = await fetch(url, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01',
      'dangerously-allow-browser': 'true'
    },
    body: JSON.stringify({
      model: modelName || 'claude-3-5-sonnet-20241022',
      max_tokens: 500,
      messages: [{
        role: 'user',
        content: [
          { type: 'image', source: { type: 'base64', media_type: 'image/png', data: base64Data } },
          { type: 'text', text: VISION_SYSTEM_PROMPT }
        ]
      }]
    })
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`Anthropic API Error (${res.status}): ${errText}`);
  }

  const data = await res.json();
  const textOut = data.content?.[0]?.text;
  return extractAndParseJson(textOut);
}

// 6. LOCAL OLLAMA VISION API CALL
async function callOllamaVisionApi(base64Png, modelName = "llava") {
  const base64Data = base64Png.replace(/^data:image\/(png|jpeg);base64,/, "");
  const url = 'http://localhost:11434/api/generate';

  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model: modelName || 'llava',
      prompt: VISION_SYSTEM_PROMPT,
      images: [base64Data],
      stream: false
    })
  });

  if (!res.ok) throw new Error(`Local Ollama AI server not reachable on http://localhost:11434 (model: ${modelName})`);
  const data = await res.json();
  return extractAndParseJson(data.response);
}

// PWA Service Worker & App Installation
let deferredPrompt = null;

if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('sw.js').catch(err => {
    console.log('Service Worker registration skipped:', err);
  });
}

window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  deferredPrompt = e;
  const installBtn = document.getElementById('pwa-install-btn');
  if (installBtn) installBtn.style.display = 'inline-flex';
});

async function installPwaApp() {
  if (!deferredPrompt) {
    downloadWindowsShortcut();
    return;
  }
  deferredPrompt.prompt();
  const { outcome } = await deferredPrompt.userChoice;
  if (outcome === 'accepted') {
    const installBtn = document.getElementById('pwa-install-btn');
    if (installBtn) installBtn.style.display = 'none';
  }
  deferredPrompt = null;
}

function openInstallModal() {
  const modal = document.getElementById("install-modal");
  if (modal) modal.classList.add("active");
}

function closeInstallModal(event) {
  const modal = document.getElementById("install-modal");
  if (modal) modal.classList.remove("active");
}

function downloadWindowsShortcut() {
  const content = `[{000214A0-0000-0000-C000-000000000046}]\nProp3=19,11\n[InternetShortcut]\nIDList=\nURL=https://pdf-cleanspace-ai-pro.vercel.app/\nIconIndex=0\nHotKey=0\nIconFile=C:\\Windows\\System32\\shell32.dll\n`;
  const blob = new Blob([content], { type: "application/x-mswinurl" });
  downloadBlob(blob, "PDF CleanSpace AI Pro.url");
}

function downloadDesktopPackage() {
  const a = document.createElement("a");
  a.href = "PDF_CleanSpace_Desktop_Package.zip";
  a.download = "PDF_CleanSpace_Desktop_Package.zip";
  document.body.appendChild(a);
  a.click();
  a.remove();
}

function openHelpModal() {
  const modal = document.getElementById("help-modal");
  if (modal) modal.classList.add("active");
}

function closeHelpModal(event) {
  const modal = document.getElementById("help-modal");
  if (modal) modal.classList.remove("active");
}

function rotatePage(pageIndex, degrees) {
  const page = pagesData.find(p => p.page_index === pageIndex);
  if (page) {
    page.user_rotation = (page.user_rotation + degrees + 360) % 360;
    renderPageGrid();
    updateSummaryStats();
  }
}

function toggleDeletePage(pageIndex) {
  const page = pagesData.find(p => p.page_index === pageIndex);
  if (page) {
    page.user_deleted = !page.user_deleted;
    renderPageGrid();
    updateSummaryStats();
  }
}

function fixAllRotations() {
  pagesData.forEach(p => {
    p.user_rotation = p.suggested_rotation;
  });
  renderPageGrid();
  updateSummaryStats();
}

function deleteAllBlankPages() {
  pagesData.forEach(p => {
    if (p.is_blank) {
      p.user_deleted = true;
    }
  });
  renderPageGrid();
  updateSummaryStats();
}

function restoreAllPages() {
  pagesData.forEach(p => {
    p.user_deleted = false;
    p.user_rotation = 0;
  });
  renderPageGrid();
  updateSummaryStats();
}

function openRecheckModal() {
  if (!pagesData || pagesData.length === 0) {
    alert("Please upload a PDF document first to review pages.");
    return;
  }
  const modal = document.getElementById("recheck-modal");
  if (modal) {
    modal.classList.add("active");
    renderRecheckGrid();
  }
}

function closeRecheckModal(event) {
  const modal = document.getElementById("recheck-modal");
  if (modal) modal.classList.remove("active");
}

function renderRecheckGrid() {
  const container = document.getElementById("recheck-page-grid");
  if (!container) return;
  container.innerHTML = "";

  const keptCount = pagesData.filter(p => !p.user_deleted).length;
  const deletedCount = pagesData.filter(p => p.user_deleted).length;

  const keptStat = document.getElementById("recheck-stat-kept");
  const deletedStat = document.getElementById("recheck-stat-deleted");
  if (keptStat) keptStat.innerText = `✓ ${keptCount} Pages Kept in Final PDF`;
  if (deletedStat) deletedStat.innerText = `❌ ${deletedCount} Pages Removed`;

  pagesData.forEach(p => {
    const card = document.createElement("div");
    card.className = `page-card ${p.user_deleted ? 'is-deleted' : ''}`;
    card.style.border = p.user_deleted ? "2px dashed #f87171" : "2px solid #10b981";
    card.style.background = p.user_deleted ? "rgba(35, 20, 25, 0.85)" : "rgba(13, 21, 32, 0.85)";

    card.innerHTML = `
      <div class="page-card-header" style="background: ${p.user_deleted ? 'rgba(239,68,68,0.2)' : 'rgba(16,185,129,0.2)'}">
        <span style="font-weight: 700; color: ${p.user_deleted ? '#f87171' : '#34d399'}">Page ${p.page_num}</span>
        <span style="font-size: 0.72rem;">${p.user_deleted ? '❌ EXCLUDED' : '✓ KEPT'}</span>
      </div>

      <div class="page-preview-wrapper" style="height: 200px; cursor: pointer;" onclick="toggleDeletePage(${p.page_index}); renderRecheckGrid();">
        <img class="page-img" src="${p.thumbnail_url}" style="transform: rotate(${p.user_rotation}deg);" alt="Page ${p.page_num}">
      </div>

      <div style="padding: 0.6rem; text-align: center; border-top: 1px solid var(--border-color);">
        <button class="btn ${p.user_deleted ? 'btn-success' : 'btn-danger'}" 
                onclick="toggleDeletePage(${p.page_index}); renderRecheckGrid();"
                style="width: 100%; justify-content: center; font-size: 0.8rem; font-weight: 700;">
          ${p.user_deleted ? '↩️ Keep in PDF' : '🗑️ Remove Page'}
        </button>
      </div>
    `;

    container.appendChild(card);
  });
}

let preparedPartsToSave = [];

async function saveBlobWithNativePicker(blob, suggestedFilename) {
  if ('showSaveFilePicker' in window) {
    try {
      const handle = await window.showSaveFilePicker({
        suggestedName: suggestedFilename,
        types: [{
          description: 'PDF Document',
          accept: { 'application/pdf': ['.pdf'] }
        }]
      });
      const writable = await handle.createWritable();
      await writable.write(blob);
      await writable.close();
      return 'saved';
    } catch (err) {
      if (err.name === 'AbortError') {
        return 'cancelled';
      }
      console.log('showSaveFilePicker fallback:', err);
    }
  }
  return false;
}

function openSavePartsModal(parts) {
  preparedPartsToSave = parts;
  const listContainer = document.getElementById("save-parts-list");
  if (!listContainer) return;

  listContainer.innerHTML = "";

  parts.forEach((part, idx) => {
    const div = document.createElement("div");
    div.className = "card";
    div.style.padding = "0.85rem 1rem";
    div.style.background = "rgba(255, 255, 255, 0.03)";
    div.style.border = "1px solid var(--border-color)";

    div.innerHTML = `
      <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 0.5rem; margin-bottom: 0.5rem;">
        <span style="font-weight: 700; font-size: 0.95rem; color: var(--accent-cyan);">
          Part ${idx + 1} (${part.pages.length} clean page${part.pages.length > 1 ? 's' : ''}: P${part.startPageNum}-P${part.endPageNum})
        </span>
        <button class="btn btn-secondary" onclick="saveSinglePartWithPicker(${idx})" style="padding: 0.35rem 0.75rem; font-size: 0.8rem;">
          📁 Choose Folder & Save Part ${idx + 1}
        </button>
      </div>
      <div class="form-group" style="margin: 0;">
        <input type="text" id="custom-name-part-${idx}" class="form-control" value="${part.defaultName}" style="font-size: 0.85rem; padding: 0.4rem 0.6rem;">
      </div>
    `;

    listContainer.appendChild(div);
  });

  document.getElementById("save-parts-modal").classList.add("active");
}

function closeSavePartsModal(event) {
  if (event && event.target !== event.currentTarget) return;
  const modal = document.getElementById("save-parts-modal");
  if (modal) modal.classList.remove("active");
}

async function saveSinglePartWithPicker(partIndex) {
  if (partIndex < 0 || partIndex >= preparedPartsToSave.length) return;
  const part = preparedPartsToSave[partIndex];
  
  const customNameInput = document.getElementById(`custom-name-part-${partIndex}`);
  let filename = customNameInput ? customNameInput.value.trim() : part.defaultName;
  if (!filename.toLowerCase().endsWith(".pdf")) filename += ".pdf";

  showLoading(`Generating PDF for ${filename}...`);
  try {
    const blob = await generatePdfBlobForSegment(part.pages);
    hideLoading();

    const pickerResult = await saveBlobWithNativePicker(blob, filename);
    if (pickerResult === 'saved') {
      alert(`✓ Saved ${filename} to your selected folder!`);
    } else if (pickerResult === 'cancelled') {
      // User cancelled dialog
    } else {
      downloadBlob(blob, filename);
    }
  } catch (err) {
    alert("Error saving part: " + err.message);
  } finally {
    hideLoading();
  }
}

async function saveAllPartsWithPicker() {
  if (preparedPartsToSave.length === 0) return;

  for (let i = 0; i < preparedPartsToSave.length; i++) {
    await saveSinglePartWithPicker(i);
    await new Promise(r => setTimeout(r, 600));
  }
  closeSavePartsModal();
}

async function generatePdfBlobForSegment(pages) {
  let pdfBuffer = null;
  if (currentFileObject) {
    pdfBuffer = await currentFileObject.arrayBuffer();
  } else if (rawFileUint8Array) {
    pdfBuffer = rawFileUint8Array.slice().buffer;
  }

  if (!pdfBuffer) {
    throw new Error("PDF file buffer not found.");
  }

  const srcPdfDoc = await PDFLib.PDFDocument.load(pdfBuffer, { ignoreEncryption: true });
  const newPdf = await PDFLib.PDFDocument.create();

  const pageIndicesToCopy = pages.map(p => p.page_index);
  const copiedPages = await newPdf.copyPages(srcPdfDoc, pageIndicesToCopy);

  copiedPages.forEach((page, copyIdx) => {
    const origPageData = pages[copyIdx];
    if (origPageData.user_rotation !== 0) {
      const existingRot = page.getRotation().angle;
      page.setRotation(PDFLib.degrees((existingRot + origPageData.user_rotation) % 360));
    }
    newPdf.addPage(page);
  });

  const pdfBytes = await newPdf.save();
  return new Blob([pdfBytes], { type: "application/pdf" });
}

async function exportCleanedPdf() {
  if (!pagesData || pagesData.length === 0) {
    alert("Please upload a PDF document first.");
    return;
  }

  const activePages = pagesData.filter(p => !p.user_deleted);
  if (activePages.length === 0) {
    alert("⚠️ All pages are currently marked for removal!\n\nPlease restore at least 1 page before downloading.");
    return;
  }

  const segments = [];
  let currentSegmentPages = [];
  let currentStartPageNum = pagesData[0].page_num;

  for (let i = 0; i < pagesData.length; i++) {
    const p = pagesData[i];
    if (!p.user_deleted) {
      currentSegmentPages.push(p);
    }

    if (mainCutIndices.has(p.page_index) || i === pagesData.length - 1) {
      if (currentSegmentPages.length > 0) {
        segments.push({
          startPageNum: currentStartPageNum,
          endPageNum: p.page_num,
          pages: [...currentSegmentPages]
        });
      }
      currentSegmentPages = [];
      if (i < pagesData.length - 1) {
        currentStartPageNum = pagesData[i + 1].page_num;
      }
    }
  }

  const baseName = currentFilename.replace(/\.pdf$/i, "");

  const partsToSave = segments.map((seg, idx) => {
    const defaultName = segments.length > 1
      ? `${baseName}_part${idx + 1}_p${seg.startPageNum}-${seg.endPageNum}_cleaned.pdf`
      : `${baseName}_cleaned.pdf`;
    return {
      partIndex: idx,
      defaultName: defaultName,
      startPageNum: seg.startPageNum,
      endPageNum: seg.endPageNum,
      pages: seg.pages
    };
  });

  openSavePartsModal(partsToSave);
}

function downloadBlob(blob, filename) {
  try {
    const reader = new FileReader();
    reader.onloadend = function() {
      const dataUrl = reader.result;
      const a = document.createElement("a");
      a.style.display = "none";
      a.href = dataUrl;
      a.download = filename;
      a.target = "_blank";
      document.body.appendChild(a);
      a.click();
      setTimeout(() => {
        a.remove();
      }, 3000);
    };
    reader.readAsDataURL(blob);
  } catch (e) {
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.style.display = "none";
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
      a.remove();
      window.URL.revokeObjectURL(url);
    }, 3000);
  }
}

let activeModalPageIndex = 0;
let currentZoomScale = 1.0;
let panTranslateX = 0;
let panTranslateY = 0;
let isPanning = false;
let panStartX = 0;
let panStartY = 0;

let currentTheme = localStorage.getItem("app_theme") || "formal-light";

function applyTheme(theme) {
  currentTheme = theme;
  localStorage.setItem("app_theme", theme);
  const btn = document.getElementById("theme-toggle-btn");

  if (theme === "dark-slate") {
    document.body.classList.add("theme-dark-slate");
    if (btn) btn.innerText = "⚪ Grey & White Theme";
  } else {
    document.body.classList.remove("theme-dark-slate");
    if (btn) btn.innerText = "🖤 Dark High-Contrast";
  }
}

function toggleAppTheme() {
  const newTheme = currentTheme === "formal-light" ? "dark-slate" : "formal-light";
  applyTheme(newTheme);
}

function openModal(pageIndex) {
  activeModalPageIndex = pageIndex;
  const page = pagesData.find(p => p.page_index === pageIndex);
  if (!page) return;

  const modalImg = document.getElementById("modal-img");
  if (modalImg) modalImg.src = page.thumbnail_url;

  document.getElementById("modal-title").innerText = `Page ${page.page_num} Inspection (${page.is_blank ? 'Blank Flagged' : 'Content Page'})`;
  
  resetModalImageZoom();
  initModalPanningEvents();

  document.getElementById("preview-modal").classList.add("active");
}

function closeModal(event) {
  if (event && event.target !== event.currentTarget) return;
  const modal = document.getElementById("preview-modal");
  if (modal) modal.classList.remove("active");
  resetModalImageZoom();
}

function updateModalTransform() {
  const modalImg = document.getElementById("modal-img");
  const page = pagesData.find(p => p.page_index === activeModalPageIndex);
  const currentRotation = page ? page.user_rotation : 0;
  if (modalImg) {
    modalImg.style.transform = `translate(${panTranslateX}px, ${panTranslateY}px) scale(${currentZoomScale}) rotate(${currentRotation}deg)`;
  }
  const badge = document.getElementById("modal-zoom-level");
  if (badge) {
    badge.innerText = `${Math.round(currentZoomScale * 100)}%`;
  }
}

function zoomInModalImage() {
  currentZoomScale = Math.min(currentZoomScale + 0.25, 5.0);
  updateModalTransform();
}

function zoomOutModalImage() {
  currentZoomScale = Math.max(currentZoomScale - 0.25, 0.5);
  updateModalTransform();
}

function resetModalImageZoom() {
  currentZoomScale = 1.0;
  panTranslateX = 0;
  panTranslateY = 0;
  updateModalTransform();
}

function handleModalWheelZoom(event) {
  event.preventDefault();
  const zoomFactor = event.deltaY < 0 ? 1.15 : 0.85;
  const newScale = Math.min(Math.max(currentZoomScale * zoomFactor, 0.5), 5.0);
  currentZoomScale = newScale;
  updateModalTransform();
}

function initModalPanningEvents() {
  const viewport = document.getElementById("modal-zoom-viewport");
  if (!viewport) return;

  viewport.onmousedown = (e) => {
    isPanning = true;
    viewport.classList.add("is-dragging");
    panStartX = e.clientX - panTranslateX;
    panStartY = e.clientY - panTranslateY;
  };

  window.onmousemove = (e) => {
    if (!isPanning) return;
    panTranslateX = e.clientX - panStartX;
    panTranslateY = e.clientY - panStartY;
    updateModalTransform();
  };

  window.onmouseup = () => {
    if (isPanning) {
      isPanning = false;
      if (viewport) viewport.classList.remove("is-dragging");
    }
  };

  // Keyboard Panning & Zoom Shortcuts
  window.onkeydown = (e) => {
    const modal = document.getElementById("preview-modal");
    if (!modal || !modal.classList.contains("active")) return;

    const step = 30;
    if (e.key === "ArrowUp") {
      panTranslateY += step;
      updateModalTransform();
    } else if (e.key === "ArrowDown") {
      panTranslateY -= step;
      updateModalTransform();
    } else if (e.key === "ArrowLeft") {
      panTranslateX += step;
      updateModalTransform();
    } else if (e.key === "ArrowRight") {
      panTranslateX -= step;
      updateModalTransform();
    } else if (e.key === "+" || e.key === "=") {
      zoomInModalImage();
    } else if (e.key === "-") {
      zoomOutModalImage();
    } else if (e.key === "0") {
      resetModalImageZoom();
    } else if (e.key === "Escape") {
      closeModal();
    }
  };
}

function setGridCardSize(size) {
  const gridContainer = document.getElementById("page-grid");
  if (!gridContainer) return;

  gridContainer.classList.remove("grid-size-small", "grid-size-medium", "grid-size-large");
  gridContainer.classList.add(`grid-size-${size}`);
}

function onBatchFilesSelected() {
  const fileInput = document.getElementById("batch-files-input");
  if (!fileInput || !fileInput.files || fileInput.files.length === 0) return;

  batchQueue = Array.from(fileInput.files).map((file, idx) => ({
    id: idx,
    filename: file.name,
    fileObject: file,
    pagesData: [],
    totalPages: 0,
    blankCount: 0,
    rotatedCount: 0,
    scanned: false,
    status: "Ready for scan"
  }));

  renderBatchResultsTable();
  document.getElementById("batch-results-container").style.display = "block";
}

async function startBatchScan() {
  const fileInput = document.getElementById("batch-files-input");
  const dirPath = document.getElementById("batch-dir").value.trim();
  const autoClean = document.getElementById("batch-autoclean").checked;
  const sensitivity = parseFloat(document.getElementById("batch-sensitivity").value);

  if (batchQueue.length === 0 && fileInput && fileInput.files.length > 0) {
    onBatchFilesSelected();
  }

  if (batchQueue.length > 0) {
    showLoading(`Processing batch dataset of ${batchQueue.length} files...`);

    for (let f = 0; f < batchQueue.length; f++) {
      const item = batchQueue[f];
      showLoading(`Scanning batch file ${f + 1} of ${batchQueue.length}: ${item.filename}...`);

      try {
        const arrayBuffer = await item.fileObject.arrayBuffer();
        const pdfDataCopy = new Uint8Array(arrayBuffer);
        const loadingTask = pdfjsLib.getDocument({ data: pdfDataCopy });
        const pdfDoc = await loadingTask.promise;
        const numPages = pdfDoc.numPages;

        item.totalPages = numPages;
        item.pagesData = [];
        let blankCount = 0;
        let rotatedCount = 0;

        for (let i = 1; i <= numPages; i++) {
          const page = await pdfDoc.getPage(i);
          const viewport = page.getViewport({ scale: 0.75 });
          const canvas = document.createElement('canvas');
          const ctx = canvas.getContext('2d');
          canvas.width = viewport.width;
          canvas.height = viewport.height;
          await page.render({ canvasContext: ctx, viewport: viewport }).promise;

          const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
          const pixels = imgData.data;
          const w = canvas.width;
          const h = canvas.height;
          const totalPixels = pixels.length / 4;

          const textContent = await page.getTextContent();
          let textCharCount = 0;
          let bodyWordCount = 0;

          textContent.items.forEach(itemText => {
            const str = itemText.str.trim();
            textCharCount += str.length;
            if (str.length > 0) {
              const validWords = str.split(/\s+/).filter(w => w.replace(/[^a-zA-Z0-9]/g, '').length >= 2);
              bodyWordCount += validWords.length;
            }
          });

          // 5x5 spatial grid density analysis
          const gridRows = 5, gridCols = 5;
          const cellW = Math.floor(w / gridCols);
          const cellH = Math.floor(h / gridRows);
          let maxGridDarkRatio = 0.0;
          let totalDarkPixels = 0;
          let activeTiles = 0;
          const activeRowSet = new Set();

          for (let r = 0; r < gridRows; r++) {
            for (let c = 0; c < gridCols; c++) {
              let cellDarkPixels = 0;
              let cellTotal = 0;
              for (let y = r * cellH; y < Math.min((r + 1) * cellH, h); y += 2) {
                for (let x = c * cellW; x < Math.min((c + 1) * cellW, w); x += 2) {
                  const idx = (y * w + x) * 4;
                  const brightness = (pixels[idx] + pixels[idx + 1] + pixels[idx + 2]) / 3;
                  cellTotal++;
                  if (brightness < 235) {
                    cellDarkPixels++;
                    totalDarkPixels++;
                  }
                }
              }
              const cellRatio = (cellDarkPixels / cellTotal) * 100.0;
              if (cellRatio > maxGridDarkRatio) maxGridDarkRatio = cellRatio;
              if (cellRatio >= 0.25) {
                activeTiles++;
                activeRowSet.add(r);
              }
            }
          }

          const activeRows = activeRowSet.size;
          const overallDarkRatio = (totalDarkPixels / totalPixels) * 100.0;

          const isBlank = !(bodyWordCount >= 3 || (activeRows >= 3 && activeTiles >= 5) || (overallDarkRatio >= 1.2 && activeTiles >= 5));
          if (isBlank) blankCount++;

          item.pagesData.push({
            page_index: i - 1,
            page_num: i,
            width: viewport.width,
            height: viewport.height,
            thumbnail_url: canvas.toDataURL('image/png'),
            word_count: bodyWordCount,
            text_char_count: textCharCount,
            dark_pixel_ratio: overallDarkRatio,
            active_tiles: activeTiles,
            active_rows: activeRows,
            is_blank: isBlank,
            blank_reason: isBlank ? `Blank Page (${bodyWordCount} words, ${activeTiles} tiles). Auto-deleted.` : `Valid Content Page (${bodyWordCount} words).`,
            suggested_rotation: 0,
            user_rotation: 0,
            user_deleted: isBlank
          });
        }

        item.blankCount = blankCount;
        item.rotatedCount = rotatedCount;
        item.scanned = true;
        item.status = "✅ Scanned & Ready";
      } catch (err) {
        item.status = "❌ Error: " + err.message;
      }
    }

    hideLoading();
    renderBatchResultsTable();
    alert(`✓ Batch dataset processing complete for ${batchQueue.length} files!\n\nYou can now inspect pages of any file, edit removals/rotations, and download cleaned PDFs.`);
    return;
  }

  if (dirPath) {
    showLoading(`Scanning server folder: ${dirPath}...`);
    try {
      const res = await fetch("/api/batch-scan-folder", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          directory_path: dirPath,
          blank_sensitivity: sensitivity,
          auto_clean: autoClean
        })
      });

      if (!res.ok) throw new Error("Batch API request failed");
      const data = await res.json();
      renderServerBatchResults(data.results);
    } catch (err) {
      alert("Batch Scan Error: " + err.message);
    } finally {
      hideLoading();
    }
  } else {
    alert("Please select PDF files or enter a directory path.");
  }
}

async function openBatchItemInViewer(batchIndex) {
  const item = batchQueue[batchIndex];
  if (!item) return;

  if (item.fileObject) {
    showLoading(`Opening ${item.filename} in PDF Viewer...`);
    try {
      const arrayBuffer = await item.fileObject.arrayBuffer();
      rawFileUint8Array = new Uint8Array(arrayBuffer);
      currentFilename = item.filename;
      viewerPdfDocument = null;
      currentViewerPageIndex = 1;
      switchTab('viewer');
    } catch (err) {
      alert("Error opening PDF in viewer: " + err.message);
    } finally {
      hideLoading();
    }
  } else if (item.pagesData && item.pagesData.length > 0) {
    pagesData = item.pagesData;
    currentFilename = item.filename;
    switchTab('viewer');
  } else {
    alert("Please wait for the file to scan before opening in PDF Viewer.");
  }
}

function renderBatchResultsTable() {
  const container = document.getElementById("batch-results-container");
  const tbody = document.getElementById("batch-table-body");
  const summaryText = document.getElementById("batch-summary-text");
  if (!tbody || !container) return;

  tbody.innerHTML = "";
  if (summaryText) summaryText.innerText = `${batchQueue.length} total batch PDF files`;

  batchQueue.forEach((item, idx) => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td><strong>${item.filename}</strong></td>
      <td>${item.totalPages || 0}</td>
      <td><span class="pill pill-blank">${item.blankCount || 0} Blanks</span></td>
      <td><span class="pill pill-rotation">${item.rotatedCount || 0} Rotated</span></td>
      <td><span class="pill pill-success">${item.status}</span></td>
      <td>
        <div style="display: flex; gap: 0.5rem; flex-wrap: wrap;">
          <button class="btn btn-secondary" onclick="openBatchItemInViewer(${idx})" style="padding: 0.35rem 0.75rem; font-size: 0.8rem; border-color: var(--accent-cyan); color: var(--accent-cyan); font-weight: 700;" title="Open this file in PDF Reader & Viewer">
            📖 View PDF
          </button>
          <button class="btn btn-secondary" onclick="inspectBatchFile(${idx})" style="padding: 0.35rem 0.75rem; font-size: 0.8rem;" title="Inspect & recheck pages for this file">
            🔍 Inspect Pages
          </button>
          <button class="btn btn-success" onclick="downloadBatchFileCleaned(${idx})" style="padding: 0.35rem 0.75rem; font-size: 0.8rem;" title="Download cleaned PDF for this file">
            💾 Download Cleaned
          </button>
        </div>
      </td>
    `;
    tbody.appendChild(tr);
  });

  container.style.display = "block";
}

function renderServerBatchResults(results) {
  const container = document.getElementById("batch-results-container");
  const tbody = document.getElementById("batch-table-body");
  if (!tbody || !container) return;

  tbody.innerHTML = "";
  results.forEach(r => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td><strong>${r.filename}</strong></td>
      <td>${r.total_pages}</td>
      <td><span class="pill pill-blank">${r.blank_count} Blanks</span></td>
      <td><span class="pill pill-rotation">${r.rotated_count} Rotated</span></td>
      <td><span class="pill pill-success">Processed</span></td>
      <td><span style="color: var(--accent-cyan); font-size: 0.8rem;">Auto-Cleaned Server</span></td>
    `;
    tbody.appendChild(tr);
  });
  container.style.display = "block";
}

function inspectBatchFile(idx) {
  if (idx < 0 || idx >= batchQueue.length) return;
  const item = batchQueue[idx];

  currentBatchIndex = idx;
  currentFilename = item.filename;
  currentFileObject = item.fileObject;
  pagesData = item.pagesData;

  onScanCompleted();
  switchTab('single');
}

async function downloadBatchFileCleaned(idx) {
  if (idx < 0 || idx >= batchQueue.length) return;
  const item = batchQueue[idx];

  if (!item.pagesData || item.pagesData.length === 0) {
    alert("Please run Dataset Scan first to process pages.");
    return;
  }

  showLoading(`Generating cleaned PDF for ${item.filename}...`);
  try {
    const arrayBuffer = await item.fileObject.arrayBuffer();
    const pdfDoc = await PDFLib.PDFDocument.load(arrayBuffer, { ignoreEncryption: true });

    item.pagesData.forEach((p, pageIdx) => {
      if (p.user_rotation !== 0) {
        const page = pdfDoc.getPage(pageIdx);
        const existingRot = page.getRotation().angle;
        page.setRotation(PDFLib.degrees((existingRot + p.user_rotation) % 360));
      }
    });

    const toDelete = item.pagesData
      .filter(p => p.user_deleted)
      .map(p => p.page_index)
      .sort((a, b) => b - a);

    toDelete.forEach(pIdx => {
      pdfDoc.removePage(pIdx);
    });

    const pdfBytes = await pdfDoc.save();
    const blob = new Blob([pdfBytes], { type: "application/pdf" });
    const cleanName = `${item.filename.replace(/\.pdf$/i, "")}_cleaned.pdf`;
    downloadBlob(blob, cleanName);
  } catch (err) {
    alert(`Error exporting ${item.filename}: ` + err.message);
  } finally {
    hideLoading();
  }
}

async function downloadAllBatchCleaned() {
  if (batchQueue.length === 0) {
    alert("No batch files loaded. Please select batch files first.");
    return;
  }

  showLoading("Generating cleaned PDFs for all batch files...");
  for (let i = 0; i < batchQueue.length; i++) {
    if (batchQueue[i].scanned) {
      await downloadBatchFileCleaned(i);
      await new Promise(r => setTimeout(r, 800));
    }
  }
  hideLoading();
}

/* ============================================================
   PDF24 STYLE VISUAL SPLIT PDF FUNCTIONS
   ============================================================ */

async function onSplitFileSelected(event) {
  const file = event.target.files[0];
  if (!file) return;
  await loadSplitPdfFile(file);
}

async function loadSplitPdfFile(file) {
  splitFileObject = file;
  splitPagesData = [];
  splitCutIndices.clear();

  showLoading(`Loading ${file.name} for visual PDF split...`);
  try {
    const arrayBuffer = await file.arrayBuffer();
    const loadingTask = pdfjsLib.getDocument({ data: new Uint8Array(arrayBuffer) });
    const pdfDoc = await loadingTask.promise;
    const numPages = pdfDoc.numPages;

    for (let i = 1; i <= numPages; i++) {
      const page = await pdfDoc.getPage(i);
      const viewport = page.getViewport({ scale: 0.5 });
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      canvas.width = viewport.width;
      canvas.height = viewport.height;
      await page.render({ canvasContext: ctx, viewport: viewport }).promise;

      splitPagesData.push({
        page_index: i - 1,
        page_num: i,
        thumbnail_url: canvas.toDataURL('image/png'),
        width: viewport.width,
        height: viewport.height
      });
    }

    document.getElementById("split-dropzone").style.display = "none";
    document.getElementById("split-controls").style.display = "block";
    document.getElementById("split-workspace").style.display = "block";

    renderSplitGrid();
  } catch (err) {
    alert("Error loading PDF for split: " + err.message);
  } finally {
    hideLoading();
  }
}

function renderSplitGrid() {
  const gridContainer = document.getElementById("split-page-grid");
  if (!gridContainer) return;
  gridContainer.innerHTML = "";

  if (splitPagesData.length === 0) return;

  let currentGroup = 0;
  const groupsCount = splitCutIndices.size + 1;

  const badge = document.getElementById("split-summary-badge");
  if (badge) {
    badge.innerText = `✂️ ${groupsCount} Output PDF File${groupsCount > 1 ? 's' : ''}`;
  }

  splitPagesData.forEach((p, idx) => {
    const wrapper = document.createElement("div");
    wrapper.className = "split-card-wrapper";

    const partClass = `part-group-${currentGroup % 6}`;

    wrapper.innerHTML = `
      <div class="split-page-card ${partClass}">
        <div style="font-size: 0.75rem; font-weight: 700; color: var(--text-muted); margin-bottom: 0.35rem; display: flex; justify-content: space-between; width: 100%;">
          <span>Page ${p.page_num}</span>
          <span style="font-size: 0.7rem; color: var(--accent-cyan);">Part ${currentGroup + 1}</span>
        </div>
        <img class="page-img" src="${p.thumbnail_url}" style="width: 100%; border-radius: 4px; box-shadow: 0 2px 6px rgba(0,0,0,0.4);" alt="Page ${p.page_num}">
      </div>
    `;

    gridContainer.appendChild(wrapper);

    if (idx < splitPagesData.length - 1) {
      const isCut = splitCutIndices.has(idx);
      const divider = document.createElement("div");
      divider.className = `scissor-divider ${isCut ? 'is-cut' : ''}`;
      divider.title = isCut ? "Click to Remove Split Cut Line" : "Click Scissor to Split PDF Here";
      divider.onclick = () => toggleScissorCut(idx);

      divider.innerHTML = `
        <div class="scissor-line"></div>
        <div class="scissor-btn">✂️</div>
      `;

      gridContainer.appendChild(divider);

      if (isCut) {
        currentGroup++;
      }
    }
  });
}

function toggleScissorCut(pageIndex) {
  if (splitCutIndices.has(pageIndex)) {
    splitCutIndices.delete(pageIndex);
  } else {
    splitCutIndices.add(pageIndex);
  }
  renderSplitGrid();
}

function resetSplitCuts() {
  splitCutIndices.clear();
  const rangeInput = document.getElementById("split-range-input");
  if (rangeInput) rangeInput.value = "";
  renderSplitGrid();
}

function onSplitModeChange() {
  const mode = document.getElementById("split-mode-select").value;
  const rangeContainer = document.getElementById("split-range-input-container");
  const everyNContainer = document.getElementById("split-every-n-container");

  if (rangeContainer) rangeContainer.style.display = mode === "range" ? "flex" : "none";
  if (everyNContainer) everyNContainer.style.display = mode === "every_n" ? "flex" : "none";

  if (mode === "every_n") {
    applyEveryNPagesSplit();
  } else if (mode === "range") {
    applyCustomRangeSplit();
  }
}

function applyEveryNPagesSplit() {
  const n = parseInt(document.getElementById("split-every-n-input").value) || 1;
  splitCutIndices.clear();

  for (let i = n - 1; i < splitPagesData.length - 1; i += n) {
    splitCutIndices.add(i);
  }
  renderSplitGrid();
}

function applyCustomRangeSplit() {
  const text = document.getElementById("split-range-input").value.trim();
  if (!text) return;

  splitCutIndices.clear();
  const parts = text.split(',');

  parts.forEach(part => {
    const rangeMatch = part.trim().match(/^(\d+)-(\d+)$/);
    if (rangeMatch) {
      const endPage = parseInt(rangeMatch[2]);
      if (endPage > 0 && endPage < splitPagesData.length) {
        splitCutIndices.add(endPage - 1);
      }
    }
  });

  renderSplitGrid();
}

async function executePdfSplit() {
  if (!splitFileObject || splitPagesData.length === 0) {
    alert("Please upload a PDF file to split first.");
    return;
  }

  showLoading("Splitting PDF document...");
  try {
    const arrayBuffer = await splitFileObject.arrayBuffer();
    const srcPdfDoc = await PDFLib.PDFDocument.load(arrayBuffer, { ignoreEncryption: true });

    const segments = [];
    let currentStart = 0;

    for (let i = 0; i < splitPagesData.length; i++) {
      if (splitCutIndices.has(i) || i === splitPagesData.length - 1) {
        segments.push({
          start: currentStart,
          end: i
        });
        currentStart = i + 1;
      }
    }

    const baseName = splitFileObject.name.replace(/\.pdf$/i, "");

    for (let s = 0; s < segments.length; s++) {
      const seg = segments[s];
      const newPdf = await PDFLib.PDFDocument.create();
      const pageIndices = [];
      for (let p = seg.start; p <= seg.end; p++) {
        pageIndices.push(p);
      }

      const copiedPages = await newPdf.copyPages(srcPdfDoc, pageIndices);
      copiedPages.forEach(p => newPdf.addPage(p));

      const pdfBytes = await newPdf.save();
      const blob = new Blob([pdfBytes], { type: "application/pdf" });
      const partName = `${baseName}_part${s + 1}_p${seg.start + 1}-${seg.end + 1}.pdf`;

      downloadBlob(blob, partName);
      await new Promise(r => setTimeout(r, 600));
    }

    alert(`✓ Successfully split PDF into ${segments.length} separate file(s)!`);
  } catch (err) {
    alert("Error executing PDF split: " + err.message);
  } finally {
    hideLoading();
  }
}

// ==========================================
// INTEGRATED PDF VIEWER ENGINE
// ==========================================
let currentViewerPageIndex = 1;
let currentViewerZoomScale = 1.0;
let currentViewerRotation = 0;
let viewerPdfDocument = null;
let isViewerRendering = false;

async function initPdfViewer() {
  const container = document.getElementById("viewer-container");
  if (!container) return;

  if (!rawFileUint8Array && (!pagesData || pagesData.length === 0)) {
    container.innerHTML = `
      <div style="text-align: center; padding: 4rem 2rem; color: var(--text-muted);">
        <div style="font-size: 3.5rem; margin-bottom: 1rem;">📖</div>
        <h3 style="font-size: 1.35rem; font-weight: 700; color: var(--text-main); margin-bottom: 0.5rem;">No PDF Document Loaded in Viewer</h3>
        <p style="font-size: 0.9rem; margin-bottom: 1.5rem;">Upload a PDF document or select any local PDF file to read and inspect.</p>
        <button class="btn btn-primary" onclick="document.getElementById('viewer-file-input').click()" style="font-weight: 700; font-size: 0.95rem; padding: 0.75rem 1.6rem; box-shadow: 0 0 20px rgba(16, 185, 129, 0.4);">
          📄 Open & Select PDF Document
        </button>
        <input type="file" id="viewer-file-input" accept=".pdf" style="display:none;" onchange="loadViewerSelectedFile(event)">
      </div>
    `;
    return;
  }

  try {
    if (!viewerPdfDocument && rawFileUint8Array) {
      const loadingTask = pdfjsLib.getDocument({ data: rawFileUint8Array });
      viewerPdfDocument = await loadingTask.promise;
    }

    if (viewerPdfDocument) {
      document.getElementById("viewer-total-pages").innerText = viewerPdfDocument.numPages;
      const numInput = document.getElementById("viewer-page-num");
      if (numInput) {
        numInput.max = viewerPdfDocument.numPages;
        numInput.value = currentViewerPageIndex;
      }
      renderViewerCurrentPage();
    }
  } catch (err) {
    console.error("PDF Viewer load error:", err);
  }
}

async function loadViewerSelectedFile(event) {
  const file = event.target.files[0];
  if (!file) return;

  const arrayBuffer = await file.arrayBuffer();
  rawFileUint8Array = new Uint8Array(arrayBuffer);
  currentFilename = file.name;
  viewerPdfDocument = null;
  currentViewerPageIndex = 1;
  initPdfViewer();
}

async function renderViewerCurrentPage() {
  if (!viewerPdfDocument || isViewerRendering) return;
  isViewerRendering = true;

  const container = document.getElementById("viewer-container");
  if (!container) return;

  try {
    const page = await viewerPdfDocument.getPage(currentViewerPageIndex);
    const viewport = page.getViewport({ scale: currentViewerZoomScale, rotation: currentViewerRotation });

    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("2d");
    canvas.height = viewport.height;
    canvas.width = viewport.width;
    canvas.style.boxShadow = "0 12px 35px rgba(0,0,0,0.6)";
    canvas.style.borderRadius = "6px";
    canvas.style.background = "#ffffff";

    const renderContext = {
      canvasContext: ctx,
      viewport: viewport
    };

    container.innerHTML = "";
    container.appendChild(canvas);
    await page.render(renderContext).promise;
  } catch (e) {
    console.error("Viewer page render error:", e);
  } finally {
    isViewerRendering = false;
  }
}

function prevViewerPage() {
  if (currentViewerPageIndex > 1) {
    currentViewerPageIndex--;
    document.getElementById("viewer-page-num").value = currentViewerPageIndex;
    renderViewerCurrentPage();
  }
}

function nextViewerPage() {
  if (viewerPdfDocument && currentViewerPageIndex < viewerPdfDocument.numPages) {
    currentViewerPageIndex++;
    document.getElementById("viewer-page-num").value = currentViewerPageIndex;
    renderViewerCurrentPage();
  }
}

function firstViewerPage() {
  currentViewerPageIndex = 1;
  document.getElementById("viewer-page-num").value = 1;
  renderViewerCurrentPage();
}

function lastViewerPage() {
  if (viewerPdfDocument) {
    currentViewerPageIndex = viewerPdfDocument.numPages;
    document.getElementById("viewer-page-num").value = currentViewerPageIndex;
    renderViewerCurrentPage();
  }
}

function gotoViewerPage(pageNum) {
  const val = parseInt(pageNum);
  if (viewerPdfDocument && val >= 1 && val <= viewerPdfDocument.numPages) {
    currentViewerPageIndex = val;
    renderViewerCurrentPage();
  }
}

function zoomViewerIn() {
  currentViewerZoomScale = Math.min(currentViewerZoomScale + 0.25, 4.0);
  document.getElementById("viewer-zoom-badge").innerText = `${Math.round(currentViewerZoomScale * 100)}%`;
  renderViewerCurrentPage();
}

function zoomViewerOut() {
  currentViewerZoomScale = Math.max(currentViewerZoomScale - 0.25, 0.4);
  document.getElementById("viewer-zoom-badge").innerText = `${Math.round(currentViewerZoomScale * 100)}%`;
  renderViewerCurrentPage();
}

function resetViewerZoom() {
  currentViewerZoomScale = 1.0;
  document.getElementById("viewer-zoom-badge").innerText = "100%";
  renderViewerCurrentPage();
}

function fitViewerWidth() {
  currentViewerZoomScale = 1.4;
  document.getElementById("viewer-zoom-badge").innerText = "140%";
  renderViewerCurrentPage();
}

function fitViewerPage() {
  currentViewerZoomScale = 0.85;
  document.getElementById("viewer-zoom-badge").innerText = "85%";
  renderViewerCurrentPage();
}

function rotateViewerLeft() {
  currentViewerRotation = (currentViewerRotation - 90 + 360) % 360;
  renderViewerCurrentPage();
}

function rotateViewerRight() {
  currentViewerRotation = (currentViewerRotation + 90) % 360;
  renderViewerCurrentPage();
}

async function searchPdfViewerText() {
  const query = document.getElementById("viewer-search-input").value.trim().toLowerCase();
  if (!query || !viewerPdfDocument) return;

  for (let i = 1; i <= viewerPdfDocument.numPages; i++) {
    const page = await viewerPdfDocument.getPage(i);
    const textContent = await page.getTextContent();
    const fullText = textContent.items.map(item => item.str).join(" ").toLowerCase();
    if (fullText.includes(query)) {
      currentViewerPageIndex = i;
      document.getElementById("viewer-page-num").value = i;
      renderViewerCurrentPage();
      alert(`🔍 Text match found for "${query}" on Page ${i}!`);
      return;
    }
  }
  alert(`No match found for "${query}" in this PDF document.`);
}

function openPdfViewerTab() {
  switchTab("viewer");
}
