#!/usr/bin/env python3
"""
CLI Tool for Headless PDF Dataset Cleaning
Detects blank pages and misoriented pages in PDF directories.
"""

import os
import sys
import argparse
from backend.pdf_processor import PDFProcessor

def main():
    parser = argparse.ArgumentParser(description="Automated PDF Blank Page Detector & Auto-Rotation CLI")
    parser.add_argument("--input", "-i", required=True, help="Input directory containing PDF files or single PDF file path")
    parser.add_argument("--output", "-o", default="", help="Output directory path for cleaned PDFs")
    parser.add_argument("--sensitivity", "-s", type=float, default=0.8, help="Blank page pixel density sensitivity threshold (default: 0.8)")
    parser.add_argument("--keep-blank", action="store_true", help="Do not remove blank pages (only fix rotations)")
    parser.add_argument("--no-rotate", action="store_true", help="Do not auto-rotate pages (only remove blank pages)")
    parser.add_argument("--ai-provider", choices=["gemini", "openai", "openrouter", "groq", "anthropic"], help="Run Multimodal AI Vision API scanning (gemini, openai, openrouter, groq, anthropic)")
    parser.add_argument("--ai-key", default="", help="AI Provider API Key")
    parser.add_argument("--ai-model", default="", help="Sub-model name (e.g. gemini-2.5-flash, gpt-4o-mini)")

    args = parser.parse_args()

    input_path = os.path.abspath(args.input)
    if not os.path.exists(input_path):
        print(f"Error: Input path '{input_path}' does not exist.")
        sys.exit(1)

    if os.path.isfile(input_path):
        pdf_files = [input_path]
        base_dir = os.path.dirname(input_path)
    else:
        base_dir = input_path
        pdf_files = [os.path.join(base_dir, f) for f in os.listdir(base_dir) if f.lower().endswith('.pdf')]

    if not pdf_files:
        print(f"No PDF files found in '{input_path}'.")
        sys.exit(0)

    output_dir = os.path.abspath(args.output) if args.output else os.path.join(base_dir, "cleaned_output")
    os.makedirs(output_dir, exist_ok=True)

    print("=" * 60)
    print(" ⚡ PDF CleanSpace - CLI Batch Processing Engine")
    print("=" * 60)
    print(f"Input path:        {input_path}")
    print(f"Output directory:  {output_dir}")
    print(f"Blank Sensitivity: {args.sensitivity}%")
    if args.ai_provider:
        print(f"AI Vision API:     {args.ai_provider.upper()} ({args.ai_model or 'Default'})")
    print(f"Total PDFs found:  {len(pdf_files)}")
    print("-" * 60)

    total_files = len(pdf_files)
    total_pages_scanned = 0
    total_blanks_removed = 0
    total_rotations_fixed = 0

    for idx, filepath in enumerate(pdf_files, 1):
        filename = os.path.basename(filepath)
        print(f"\n[{idx}/{total_files}] Processing: {filename}...")

        try:
            processor = PDFProcessor(filepath)
            page_count = processor.page_count
            total_pages_scanned += page_count

            actions = []
            file_blanks = 0
            file_rotations = 0

            for i in range(page_count):
                if args.ai_provider and args.ai_key:
                    try:
                        ai_res = processor.ai_classify_page(i, provider=args.ai_provider, api_key=args.ai_key, model_name=args.ai_model)
                        is_blank = ai_res["is_blank"] and not args.keep_blank
                        suggested_rotation = 0 if args.no_rotate else ai_res["suggested_rotation"]
                    except Exception as ai_err:
                        print(f"    ⚠️ Page {i+1} AI error ({ai_err}), falling back to hybrid rule classifier...")
                        analysis = processor.analyze_page(i, blank_sensitivity=args.sensitivity)
                        is_blank = analysis["is_blank"] and not args.keep_blank
                        suggested_rotation = 0 if args.no_rotate else analysis["suggested_rotation"]
                else:
                    analysis = processor.analyze_page(i, blank_sensitivity=args.sensitivity)
                    is_blank = analysis["is_blank"] and not args.keep_blank
                    suggested_rotation = 0 if args.no_rotate else analysis["suggested_rotation"]

                if is_blank:
                    file_blanks += 1
                if suggested_rotation != 0:
                    file_rotations += 1

                actions.append({
                    "page_index": i,
                    "deleted": is_blank,
                    "rotation": suggested_rotation
                })

            cleaned_bytes = processor.export_cleaned_pdf(actions)
            processor.close()

            out_filename = f"{os.path.splitext(filename)[0]}_cleaned.pdf"
            out_filepath = os.path.join(output_dir, out_filename)

            with open(out_filepath, "wb") as f_out:
                f_out.write(cleaned_bytes)

            total_blanks_removed += file_blanks
            total_rotations_fixed += file_rotations

            print(f"  ✓ Total Pages: {page_count} | Blank Removed: {file_blanks} | Rotations Fixed: {file_rotations}")
            print(f"  ✓ Saved to: {out_filepath}")

        except Exception as e:
            print(f"  ❌ Error processing '{filename}': {str(e)}")

    print("\n" + "=" * 60)
    print(" BATCH PROCESSING COMPLETE SUMMARY")
    print("=" * 60)
    print(f"Files Processed:   {total_files}")
    print(f"Total Pages:       {total_pages_scanned}")
    print(f"Blanks Removed:    {total_blanks_removed}")
    print(f"Rotations Fixed:   {total_rotations_fixed}")
    print(f"Cleaned Output:    {output_dir}")
    print("=" * 60)

if __name__ == "__main__":
    main()
